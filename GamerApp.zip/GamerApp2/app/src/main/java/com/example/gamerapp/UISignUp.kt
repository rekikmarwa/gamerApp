package com.example.gamerapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class UISignUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_uisign_up)
    }
}